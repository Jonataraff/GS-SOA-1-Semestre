package com.fiap.skillup.skillup.controller;

import com.fiap.skillup.skillup.dto.TrilhaDTO;
import com.fiap.skillup.skillup.service.TrilhaService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/trilhas")
public class TrilhaController {

    private final TrilhaService trilhaService;

    public TrilhaController(TrilhaService trilhaService) {
        this.trilhaService = trilhaService;
    }

    // GET /trilhas
    @GetMapping
    public ResponseEntity<List<TrilhaDTO>> listarTodas() {
        return ResponseEntity.ok(trilhaService.findAll());
    }

    // GET /trilhas/{id}
    @GetMapping("/{id}")
    public ResponseEntity<TrilhaDTO> buscarPorId(@PathVariable Long id) {
        TrilhaDTO dto = trilhaService.findById(id); // lança TrilhaNaoEncontradaException se não achar
        return ResponseEntity.ok(dto);
    }

    // POST /trilhas
    @PostMapping
    public ResponseEntity<TrilhaDTO> criar(
            @Valid @RequestBody TrilhaDTO trilhaDTO,
            UriComponentsBuilder uriBuilder
    ) {
        TrilhaDTO criado = trilhaService.create(trilhaDTO);
        URI location = uriBuilder.path("/trilhas/{id}")
                .buildAndExpand(criado.getId())
                .toUri();
        return ResponseEntity.created(location).body(criado);
    }

    // PUT /trilhas/{id}
    @PutMapping("/{id}")
    public ResponseEntity<TrilhaDTO> atualizar(
            @PathVariable Long id,
            @Valid @RequestBody TrilhaDTO trilhaDTO
    ) {
        TrilhaDTO atualizado = trilhaService.update(id, trilhaDTO);
        return ResponseEntity.ok(atualizado);
    }

    // DELETE /trilhas/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        trilhaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}