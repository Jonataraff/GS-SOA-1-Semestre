package com.fiap.skillup.skillup.dto;

import com.fiap.skillup.skillup.domain.Trilha;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class TrilhaDTO {

    private Long id;

    @NotBlank(message = "O nome da trilha é obrigatório.")
    @Size(min = 3, max = 150, message = "O nome deve ter entre 3 e 150 caracteres.")
    private String nome;

    @Size(max = 500, message = "A descrição deve ter no máximo 500 caracteres.")
    private String descricao;

    @Pattern(
            regexp = "INICIANTE|INTERMEDIARIO|AVANCADO",
            message = "O nível deve ser INICIANTE, INTERMEDIARIO ou AVANCADO."
    )
    private String nivel;

    @Min(value = 1, message = "A carga horária deve ser maior que zero.")
    private Integer cargaHoraria;

    @Size(max = 100, message = "O foco principal deve ter no máximo 100 caracteres.")
    private String focoPrincipal;

    public TrilhaDTO() {}

    // GETTERS e SETTERS
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNivel() {
        return nivel;
    }
    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public Integer getCargaHoraria() {
        return cargaHoraria;
    }
    public void setCargaHoraria(Integer cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getFocoPrincipal() {
        return focoPrincipal;
    }
    public void setFocoPrincipal(String focoPrincipal) {
        this.focoPrincipal = focoPrincipal;
    }

    // ➤ Entity → DTO
    public static TrilhaDTO fromEntity(Trilha trilha) {
        TrilhaDTO dto = new TrilhaDTO();
        dto.setId(trilha.getId());
        dto.setNome(trilha.getNome());
        dto.setDescricao(trilha.getDescricao());
        dto.setNivel(trilha.getNivel());
        dto.setCargaHoraria(trilha.getCargaHoraria());
        dto.setFocoPrincipal(trilha.getFocoPrincipal());
        return dto;
    }

    // ➤ DTO → Entity
    public Trilha toEntity() {
        Trilha trilha = new Trilha();
        trilha.setId(this.id);
        trilha.setNome(this.nome);
        trilha.setDescricao(this.descricao);
        trilha.setNivel(this.nivel);
        trilha.setCargaHoraria(this.cargaHoraria);
        trilha.setFocoPrincipal(this.focoPrincipal);
        return trilha;
    }
}