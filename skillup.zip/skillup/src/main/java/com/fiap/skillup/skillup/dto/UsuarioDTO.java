package com.fiap.skillup.skillup.dto;

import com.fiap.skillup.skillup.domain.Usuario;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class UsuarioDTO {

    private Long id;

    @NotBlank(message = "O nome não pode estar vazio.")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres.")
    private String nome;

    @Email(message = "Formato de email inválido.")
    @NotBlank(message = "O email é obrigatório.")
    private String email;

    @Size(max = 100, message = "A área de atuação deve ter no máximo 100 caracteres.")
    private String areaAtuacao;

    @Size(max = 50, message = "O nível de carreira deve ter no máximo 50 caracteres.")
    private String nivelCarreira;

    public UsuarioDTO() {}

    // GETTERS e SETTERS
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getAreaAtuacao() {
        return areaAtuacao;
    }
    public void setAreaAtuacao(String areaAtuacao) {
        this.areaAtuacao = areaAtuacao;
    }

    public String getNivelCarreira() {
        return nivelCarreira;
    }
    public void setNivelCarreira(String nivelCarreira) {
        this.nivelCarreira = nivelCarreira;
    }

    // ➤ Converte Entity → DTO
    public static UsuarioDTO fromEntity(Usuario usuario) {
        UsuarioDTO dto = new UsuarioDTO();
        dto.setId(usuario.getId());
        dto.setNome(usuario.getNome());
        dto.setEmail(usuario.getEmail());
        dto.setAreaAtuacao(usuario.getAreaAtuacao());
        dto.setNivelCarreira(usuario.getNivelCarreira());
        return dto;
    }

    // ➤ Converte DTO → Entity (usado em CREATE)
    public Usuario toEntity() {
        Usuario usuario = new Usuario();
        usuario.setId(this.id);
        usuario.setNome(this.nome);
        usuario.setEmail(this.email);
        usuario.setAreaAtuacao(this.areaAtuacao);
        usuario.setNivelCarreira(this.nivelCarreira);
        return usuario;
    }
}
