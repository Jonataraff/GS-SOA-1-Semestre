package com.fiap.skillup.skillup.repository;

import com.fiap.skillup.skillup.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

}