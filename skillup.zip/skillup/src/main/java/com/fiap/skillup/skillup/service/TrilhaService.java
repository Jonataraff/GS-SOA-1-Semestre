package com.fiap.skillup.skillup.service;

import com.fiap.skillup.skillup.domain.Trilha;
import com.fiap.skillup.skillup.dto.TrilhaDTO;
import com.fiap.skillup.skillup.exception.TrilhaNaoEncontradaException;
import com.fiap.skillup.skillup.repository.TrilhaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TrilhaService {

    private final TrilhaRepository trilhaRepository;

    public TrilhaService(TrilhaRepository trilhaRepository) {
        this.trilhaRepository = trilhaRepository;
    }

    // LISTAR TODAS
    public List<TrilhaDTO> findAll() {
        return trilhaRepository.findAll()
                .stream()
                .map(TrilhaDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // BUSCAR POR ID
    public TrilhaDTO findById(Long id) {
        Trilha trilha = trilhaRepository.findById(id)
                .orElseThrow(() -> new TrilhaNaoEncontradaException(id));

        return TrilhaDTO.fromEntity(trilha);
    }

    // CRIAR
    public TrilhaDTO create(TrilhaDTO dto) {

        Trilha trilha = new Trilha();
        trilha.setNome(dto.getNome());
        trilha.setDescricao(dto.getDescricao());
        trilha.setNivel(dto.getNivel());
        trilha.setCargaHoraria(dto.getCargaHoraria());
        trilha.setFocoPrincipal(dto.getFocoPrincipal());

        Trilha salva = trilhaRepository.save(trilha);

        return TrilhaDTO.fromEntity(salva);
    }

    // ATUALIZAR
    public TrilhaDTO update(Long id, TrilhaDTO dto) {

        Trilha trilha = trilhaRepository.findById(id)
                .orElseThrow(() -> new TrilhaNaoEncontradaException(id));

        trilha.setNome(dto.getNome());
        trilha.setDescricao(dto.getDescricao());
        trilha.setNivel(dto.getNivel());
        trilha.setCargaHoraria(dto.getCargaHoraria());
        trilha.setFocoPrincipal(dto.getFocoPrincipal());

        Trilha atualizada = trilhaRepository.save(trilha);

        return TrilhaDTO.fromEntity(atualizada);
    }

    // DELETAR
    public void delete(Long id) {
        Trilha trilha = trilhaRepository.findById(id)
                .orElseThrow(() -> new TrilhaNaoEncontradaException(id));

        trilhaRepository.delete(trilha);
    }
}