package com.fiap.skillup.skillup.service;

import com.fiap.skillup.skillup.domain.Usuario;
import com.fiap.skillup.skillup.dto.UsuarioDTO;
import com.fiap.skillup.skillup.exception.UsuarioNaoEncontradoException;
import com.fiap.skillup.skillup.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    // LISTAR TODOS
    public List<UsuarioDTO> findAll() {
        return usuarioRepository.findAll()
                .stream()
                .map(UsuarioDTO::fromEntity)
                .collect(Collectors.toList());
    }

    // BUSCAR POR ID
    public UsuarioDTO findById(Long id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new UsuarioNaoEncontradoException(id));

        return UsuarioDTO.fromEntity(usuario);
    }

    // CRIAR
    public UsuarioDTO create(UsuarioDTO dto) {

        Usuario usuario = new Usuario();
        usuario.setNome(dto.getNome());
        usuario.setEmail(dto.getEmail());
        usuario.setAreaAtuacao(dto.getAreaAtuacao());
        usuario.setNivelCarreira(dto.getNivelCarreira());
        usuario.setDataCadastro(LocalDate.now());

        Usuario salvo = usuarioRepository.save(usuario);

        return UsuarioDTO.fromEntity(salvo);
    }

    // ATUALIZAR
    public UsuarioDTO update(Long id, UsuarioDTO dto) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new UsuarioNaoEncontradoException(id));

        usuario.setNome(dto.getNome());
        usuario.setEmail(dto.getEmail());
        usuario.setAreaAtuacao(dto.getAreaAtuacao());
        usuario.setNivelCarreira(dto.getNivelCarreira());

        Usuario atualizado = usuarioRepository.save(usuario);

        return UsuarioDTO.fromEntity(atualizado);
    }

    // DELETAR
    public void delete(Long id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new UsuarioNaoEncontradoException(id));

        usuarioRepository.delete(usuario);
    }
}