package com.fiap.skillup.skillup.controller;

import com.fiap.skillup.skillup.dto.UsuarioDTO;
import com.fiap.skillup.skillup.service.UsuarioService;
import com.fiap.skillup.skillup.exception.UsuarioNaoEncontradoException;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // GET /usuarios
    @GetMapping
    public ResponseEntity<List<UsuarioDTO>> listarTodos() {
        List<UsuarioDTO> lista = usuarioService.findAll();
        return ResponseEntity.ok(lista);
    }

    // GET /usuarios/{id}
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> buscarPorId(@PathVariable Long id) {
        UsuarioDTO dto = usuarioService.findById(id); // pode lançar UsuarioNaoEncontradoException
        return ResponseEntity.ok(dto);
    }

    // POST /usuarios
    @PostMapping
    public ResponseEntity<UsuarioDTO> criar(
            @Valid @RequestBody UsuarioDTO usuarioDTO,
            UriComponentsBuilder uriBuilder
    ) {
        UsuarioDTO criado = usuarioService.create(usuarioDTO);
        URI location = uriBuilder.path("/usuarios/{id}")
                .buildAndExpand(criado.getId())
                .toUri();
        return ResponseEntity.created(location).body(criado);
    }

    // PUT /usuarios/{id}
    @PutMapping("/{id}")
    public ResponseEntity<UsuarioDTO> atualizar(
            @PathVariable Long id,
            @Valid @RequestBody UsuarioDTO usuarioDTO
    ) {
        UsuarioDTO atualizado = usuarioService.update(id, usuarioDTO); // lançar 404 se não encontrado
        return ResponseEntity.ok(atualizado);
    }

    // DELETE /usuarios/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        usuarioService.delete(id); // lançar 404 se não encontrado
        return ResponseEntity.noContent().build();
    }
}
