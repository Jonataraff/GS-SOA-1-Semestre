package com.fiap.skillup.skillup.repository;

import com.fiap.skillup.skillup.domain.Trilha;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrilhaRepository extends JpaRepository<Trilha, Long> {

}