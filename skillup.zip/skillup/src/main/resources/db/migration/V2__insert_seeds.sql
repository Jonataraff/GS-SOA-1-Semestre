-- =======================================
-- SEEDS DE TRILHAS
-- =======================================
INSERT INTO trilhas (nome, descricao, nivel, carga_horaria, foco_principal)
VALUES
('Introdução à Inteligência Artificial', 'Fundamentos de IA e aplicações modernas.', 'INICIANTE', 40, 'IA'),
('Análise de Dados 2030', 'Trilha completa com Python, ETL e Machine Learning.', 'INTERMEDIARIO', 60, 'Dados'),
('Soft Skills do Futuro', 'Habilidades humanas essenciais para 2030.', 'INICIANTE', 20, 'Soft Skills'),
('Tecnologias Verdes e Sustentabilidade', 'Competências para o futuro sustentável.', 'AVANCADO', 30, 'Green Tech');

-- =======================================
-- SEEDS DE COMPETÊNCIAS
-- =======================================
INSERT INTO competencias (nome, categoria, descricao)
VALUES
('Inteligência Artificial', 'Tecnologia', 'Conceitos essenciais de IA para 2030.'),
('Análise de Dados', 'Tecnologia', 'Manipulação, visualização e análise de dados.'),
('Comunicação Empática', 'Humana', 'Habilidade essencial na colaboração remota.'),
('Colaboração', 'Humana', 'Trabalho em equipe eficiente e adaptável.'),
('Sustentabilidade', 'Green Tech', 'Competências ambientais e tecnológicas.');

-- =======================================
-- SEED: RELAÇÃO TRILHA <-> COMPETÊNCIA
-- =======================================

-- Trilhas:
-- 1 = IA
-- 2 = Dados
-- 3 = Soft Skills
-- 4 = Green Tech

-- Competências:
-- 1 = IA
-- 2 = Dados
-- 3 = Empatia
-- 4 = Colaboração
-- 5 = Sustentabilidade

-- RELAÇÕES
INSERT INTO trilha_competencia (trilha_id, competencia_id)
VALUES
(1, 1),  -- IA → Inteligência Artificial
(2, 2),  -- Dados → Análise de Dados
(3, 3),  -- Soft Skills → Comunicação Empática
(3, 4),  -- Soft Skills → Colaboração
(4, 5);  -- Green Tech → Sustentabilidade

-- =======================================
-- SEED: USUÁRIO INICIAL
-- =======================================
INSERT INTO usuarios (nome, email, area_atuacao, nivel_carreira, data_cadastro)
VALUES
('Usuário Inicial', 'usuario@exemplo.com', 'Tecnologia', 'Junior', CURRENT_DATE);

-- =======================================
-- FIM DOS SEEDS
-- =======================================